# API REST con Express – Gestión de Recursos

Este proyecto consiste en una API RESTful desarrollada con Node.js y Express para gestionar recursos de temática libre. Implementa operaciones CRUD completas, validaciones de datos con Joi, autenticación con JWT y persistencia en archivo JSON.

---

## 🚀 Cómo ejecutar el proyecto

1. Clona el repositorio o descarga los archivos.
2. Instala las dependencias:

```bash
npm install
```

3. Crea un archivo `.env` en la raíz del proyecto con el siguiente contenido:

```
PORT=3000
JWT_SECRET=miclaveultrasecreta
```

4. Ejecuta el servidor:

```bash
node index.js
# o usando nodemon
npm run start
```

---

## 📦 Endpoints de la API

### 🔐 Autenticación

#### POST `/login`
Permite autenticarse con usuario y contraseña.

- **Body JSON:**
```json
{
  "username": "admin",
  "password": "1234"
}
```

- **Respuesta:**
```json
{ "token": "..." }
```

---

### 📘 Recursos

#### GET `/recursos`
Lista todos los recursos.

#### GET `/recursos/:id`
Devuelve un recurso por su ID.

#### POST `/recursos` _(protegido con JWT)_
Crea un nuevo recurso.

- **Body JSON:**
```json
{
  "nombre": "Nombre del recurso",
  "descripcion": "Texto opcional",
  "fecha": "2025-06-18"
}
```

#### PUT `/recursos/:id` _(protegido con JWT)_
Actualiza un recurso existente.

#### DELETE `/recursos/:id` _(protegido con JWT)_
Elimina un recurso por su ID.

---

## ✅ Validaciones implementadas

- `nombre`: obligatorio, mínimo 3 caracteres.
- `descripcion`: opcional.
- `fecha`: obligatoria, formato válido `YYYY-MM-DD`.

---

## 🧱 Tecnologías utilizadas

- Node.js
- Express
- Joi (validación)
- JWT (autenticación)
- dotenv
- morgan
- uuid
- fs para manejo de archivos JSON

---



