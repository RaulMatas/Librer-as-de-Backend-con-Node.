const express = require('express');
const router = express.Router();
const controller = require('../controllers/recursoController');
const validate = require('../middlewares/validateMiddleware');
const auth = require('../middlewares/authMiddleware');

router.get('/', controller.getAllRecursos);
router.get('/:id', controller.getRecursoById);
router.post('/', auth, validate, controller.createRecurso);
router.put('/:id', auth, validate, controller.updateRecurso);
router.delete('/:id', auth, controller.deleteRecurso);

module.exports = router;
