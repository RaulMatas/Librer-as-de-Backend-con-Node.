const Joi = require('joi');

const schema = Joi.object({
  nombre: Joi.string().min(3).required(),
  descripcion: Joi.string().optional(),
  fecha: Joi.date().iso().required()
});

module.exports = (req, res, next) => {
  const { error } = schema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });
  next();
};
