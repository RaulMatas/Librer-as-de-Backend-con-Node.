const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const dataPath = path.join(__dirname, '../data/data.json');

const readData = () => JSON.parse(fs.readFileSync(dataPath));
const writeData = (data) => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

exports.getAllRecursos = (req, res) => {
  const data = readData();
  res.json(data);
};

exports.getRecursoById = (req, res) => {
  const data = readData();
  const recurso = data.find(r => r.id === req.params.id);
  if (!recurso) return res.status(404).json({ error: 'Recurso no encontrado' });
  res.json(recurso);
};

exports.createRecurso = (req, res) => {
  const data = readData();
  const nuevo = { id: uuidv4(), ...req.body };
  data.push(nuevo);
  writeData(data);
  res.status(201).json(nuevo);
};

exports.updateRecurso = (req, res) => {
  const data = readData();
  const index = data.findIndex(r => r.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Recurso no encontrado' });
  data[index] = { ...data[index], ...req.body };
  writeData(data);
  res.json(data[index]);
};

exports.deleteRecurso = (req, res) => {
  const data = readData();
  const nuevoData = data.filter(r => r.id !== req.params.id);
  writeData(nuevoData);
  res.status(204).end();
};
